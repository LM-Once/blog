package com.it.controller.swing;

public class StartAppTest {

    public static void main(String[] args) {

    }
}
