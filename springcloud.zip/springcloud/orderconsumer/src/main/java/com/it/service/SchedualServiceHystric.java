package com.it.service;

import com.it.Common.RetResponse;
import com.it.Common.RetResult;

/**
 * @author 18576756475
 * @version V1.0
 * @ClassName SchedualServiceHystric
 * @Description TODO
 * @Date 2020-01-15 11:35:00
 **/
public class SchedualServiceHystric/* implements UserService*/{

    /*@Override*/
    public RetResult doLogin(String username, String password) {

        return RetResponse.makeOkMsg("服务器开小差了");
    }
}
