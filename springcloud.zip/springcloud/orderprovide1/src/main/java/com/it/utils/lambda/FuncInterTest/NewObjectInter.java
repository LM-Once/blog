package com.it.utils.lambda.FuncInterTest;

@FunctionalInterface
public interface NewObjectInter<T> {

    T build();
}
