package com.it.utils.pdfUtil;

/**
 *
 */
public class Constant {
    public static final String TITLE = "Log解析测试结果报告";

    public static final String reportTime = "1. 测试时间";

    public static final String FIRST_CONTENT_TITLE = "2. 测试内容";

    public static final String SECOND_CONTENT_TITLE = "2.1 测试内容";

    public static final String FIRST_RESULT_TITLE = "3. 测试结果";

    public static final String SECOND_RESULT_DATA_TITLE = "3.1 测试结果分析";

    public static final String BUG_ID = "bugId: ";
}
