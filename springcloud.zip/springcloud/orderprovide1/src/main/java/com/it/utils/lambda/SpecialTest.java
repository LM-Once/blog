package com.it.utils.lambda;

public interface SpecialTest {
    Object getBtModel();
}
