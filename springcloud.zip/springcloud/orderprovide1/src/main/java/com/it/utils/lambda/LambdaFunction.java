package com.it.utils.lambda;

import java.util.Set;

@FunctionalInterface
public interface LambdaFunction {

    String toString(Set<String> accountSet);

}
