package com.it.common.queue;

/**
 * @author 18576756475
 * @version V1.0
 * @ClassName BlockingQueueTest
 * @Description TODO
 * @Date 2019-12-18 10:52:18
 **/
public class BlockingQueueTest {
}
